
// example class where wll run the requirements and client needs (declaration)

public class interexamp implements Bicycle {

    int cadence = 0;
    int speed = 10;
    int gear = 1;


    public void changeCadence(int newValue) {
        cadence = newValue;
        System.out.println(cadence);
    }

    public void changeGear(int newValue) {
        gear = newValue;
        System.out.println(gear);
    }

    public void speedUp(){
        System.out.println("speed up is"+speed);
    }

    public void model(){
        System.out.println("model is hercules");
    }


    //public void speedUp(int increment) {
      //  speed = speed + increment;
        //System.out.println(speed);
    //}

    public void applyBrakes(int decrement) {
        speed = speed - decrement;
        System.out.println(speed);
    }

    void printStates() {
        System.out.println("cadence:" +
                cadence + " speed:" +
                speed + " gear:" + gear);
    }

}







