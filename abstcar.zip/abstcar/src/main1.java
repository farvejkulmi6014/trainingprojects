
//main class declaration the code wll run from here
public class main1 {

    public static void main(String[] args) {
        interexamp obj = new interexamp();
        obj.changeCadence(2);
        obj.changeGear(4);
        obj.speedUp();
        obj.applyBrakes(2);
        obj.model();

    }
}
