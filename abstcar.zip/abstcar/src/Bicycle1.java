public interface Bicycle1 {

    public abstract void model();
}
