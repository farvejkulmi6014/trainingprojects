
//iteration class1 we can have any no of iteration classes
public interface Bicycle extends Bicycle1 {

    public abstract void changeCadence(int newValue);

    public abstract void changeGear(int newValue);

    public abstract void speedUp();

    public abstract void applyBrakes(int decrement);
}