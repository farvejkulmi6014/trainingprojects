package com.company;

public class main2 {
    public static void main(String[] args){
        Exceptionex.show();
    }
}
