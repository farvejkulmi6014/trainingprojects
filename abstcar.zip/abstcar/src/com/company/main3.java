package com.company;

class main3 {

    static void printPairs(int arr[], int n)
    {
        int count=0;
        try{
        for (int i = 0; i <= n; i++) {
            for (int j = i; j < n-1; j++) {
                System.out.print("(" + arr[i] + ", "
                        + arr[j + 1] + ")"
                        + ", ");
                count++;
            }

            }

        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("its array out index");
        }

        System.out.println("the count is:"+count);
    }
    public static void main(String[] args)
    {
        int arr[] = { 1, 2,3,4,5,6,7,8,9 };
        int n = arr.length;


        printPairs(arr, n);

    }
}

