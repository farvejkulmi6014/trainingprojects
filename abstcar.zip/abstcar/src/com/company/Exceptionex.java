package com.company;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class Exceptionex {
    public static void show(){
            try {
                var reader = new FileReader("file1.txt");
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            System.out.println("file is opening now");

    }

}



