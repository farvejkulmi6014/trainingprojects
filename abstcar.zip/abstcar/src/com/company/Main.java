package com.company;

abstract class Car{
    abstract void start();
    abstract void stop();
    abstract void brek();

}

class Swift extends Car{
    void start(){
        System.out.println("swift starts");
    }
    void stop(){
        System.out.println("swift stops");
    }
    void brek(){
        System.out.println("swift slows");
    }

}

class BMW extends Car{
    void start(){
        System.out.println("BMW starts");
    }
    void stop(){
        System.out.println("BMW stops");
    }
    void brek(){
        System.out.println("BMW slows");
    }
}

public class Main {
    public static void main(String[] args){
        Car obj1=new Swift();
        Car obj2=new BMW();
        obj1.start();
        obj1.stop();
        obj1.brek();
        obj2.start();
        obj2.stop();
        obj2.brek();
       //((Swift) obj).elements();
       //((BMW) obj).elements();

    }
}
