public class interexam {
}
