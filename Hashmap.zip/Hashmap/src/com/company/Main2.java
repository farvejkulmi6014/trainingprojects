package com.company;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilePermission;
import java.nio.charset.StandardCharsets;
import java.security.PermissionCollection;

class Main2 {
    public static void main(String args[]) {
        try {
            String srg = "C:\\IO\\test1.txt";
            FilePermission file1 = new FilePermission("C:\\IO\\-", "read");
            PermissionCollection permission = file1.newPermissionCollection();
            permission.add(file1);
            FilePermission file2 = new FilePermission(srg, "write");
            permission.add(file2);
            if (permission.implies(new FilePermission(srg, "read,write"))) {
                System.out.println("Read, Write permission is granted for the path " + srg);
            } else {
                System.out.println("No Read, Write permission is granted for the path " + srg);
            }
        }catch(Exception e) {
            System.out.println(e);
        }
    }
}



