package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Main{

    public static void main(String[] args) {
            List<String> list1 = new ArrayList<String>();
            list1.add("sun");
            list1.add("moon");
            list1.add("sky");
            list1.add("universe");

            List<String> list2 = new ArrayList<String>();
            list2.add("hi");
            list2.add("hello");

            List<String> concatenated_list = new ArrayList<String>();

            concatenated_list.addAll(list1);
            concatenated_list.addAll(list2);

            System.out.println("list1: " + list1);
            System.out.println("list2: " + list2);
            System.out.println("Concatenated list is: "+ concatenated_list);
        }
    }

















