import java.util.List;

public class Listcat {
    public static void main(String[] args){


    }
}
