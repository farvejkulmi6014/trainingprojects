public interface PassengerInterface {
    public void option();
    public void addPassengerinfo();
    public void getPassengerinfo();
    public void updatePassengerinfo();

}
