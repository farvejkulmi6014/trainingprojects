
import java.util.HashMap;
import java.util.Scanner;

public class Passenger implements PassengerInterface  {
    HashMap<String, HashMap> passenger = new  HashMap<String, HashMap>();
    Scanner sc =new Scanner(System.in);

    public void option(){
        while(true){
            System.out.println("1:book ur journey\n2:scheduled journey\n3:cancel journey\n4:exit");
            System.out.println("\nselect option from above");
            int option = sc.nextInt();
            switch(option){
                case 1:
                    addPassengerinfo();
                    break;
                case 2:
                    getPassengerinfo();
                    break;
                case 3:
                    updatePassengerinfo();
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("select valid option");
            }
        }
    }

    public void addPassengerinfo() {
        System.out.println("enter pnr");
        String pnr= sc.next();
        HashMap<String,String> PassengerInfo=new  HashMap<String,String>();
        System.out.println("enter passenger name");
        PassengerInfo.put("name", sc.next());
        System.out.println("enter source station");
        PassengerInfo.put("source", sc.next());
        System.out.println("enter destination station");
        PassengerInfo.put("destination", sc.next());
        System.out.println("enter date of jorney");
        PassengerInfo.put("date", sc.next());

        passenger.put(pnr,PassengerInfo);
    }

    public void getPassengerinfo() {
        System.out.println("enter pnr");
        String pnr = sc.next();
        if (passenger.containsKey(pnr)) {
            HashMap PassengerInfo = passenger.get(pnr);
            if (!PassengerInfo.isEmpty()) {
                System.out.println("name:" +PassengerInfo.get("name"));
                System.out.println("source:"+PassengerInfo.get("source"));
                System.out.println("destination :"+PassengerInfo.get("destination"));
                System.out.println("date :"+PassengerInfo.get("date"));


            }
        } else
            System.out.println("enter valid pnr");
    }
    public void updatePassengerinfo(){
        System.out.println("enter pnr");
        String pnr= sc.next();
        if(passenger.containsKey(pnr))
        passenger.remove(pnr);
        else
            System.out.println("invalid pnr");
    }
    public static void main(String[] args){
        Passenger obj= new Passenger();
        obj.option();
    }

}
